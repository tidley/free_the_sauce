# Free the Sauce
Let data be free.

Short demo
https://www.youtube.com/shorts/g-22A-N6_I8

IMG_20220329_120715.jpg - bafkreictuxpjnldmh2dtay3eq4u5cwygbxqs2bjpset5l77ydfqxvx7qnm
## Todo
1. Upload multiple  
    1. Seperately
    1. As one (compress)
1. Remove files in app storage when clicking clean / remove
1. Qr scan for nft.storage key
1. Add 'Share all' buttons
1. Add dividers in layout https://www.woolha.com/tutorials/flutter-using-divider-and-verticaldivider-widgets-examples


1. https://riverpod.dev/docs/providers/future_provider

## Resources
Share
https://www.digitalocean.com/community/tutorials/flutter-share-plugin
FutureBuilder
https://flutterigniter.com/build-widget-with-async-method-call/
Rebuilds
https://flutterigniter.com/future-async-called-multiple-times/